# SmartFabX

## Setup Instructions

1. Install dependencies
2. Configure .env
3. Run both client and server